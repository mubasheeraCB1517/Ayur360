import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';

class LOGINPAGE extends StatefulWidget {
  const LOGINPAGE({Key? key}) : super(key: key);

  @override
  _LOGIN_PAGEState createState() => _LOGIN_PAGEState();
}

class _LOGIN_PAGEState extends State<LOGINPAGE> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
 body: Container(
   color: Colors.red,
 ),
    );
  }
}
