final String baseUrl ="https://app.ayur360.in/";
final String projectType="EDO";