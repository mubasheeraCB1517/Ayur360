import 'package:flutter/material.dart';

const MaterialColor kMaterialPrimaryColor = MaterialColor(_kprimarycolorPrimaryValue, <int, Color>{
  50: Color( 0xFF0F4A05),

});
const int _kprimarycolorPrimaryValue = 0xFF9279BA;